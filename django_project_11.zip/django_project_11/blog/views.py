from django.shortcuts import render

def home(request):
    return render(request, 'blog/home.html')

def about(request):
    return render(request, 'blog/about.html')

def post_detail(request, post_id):
    # Здесь можно добавить логику для получения поста по ID
    return render(request, 'blog/post_detail.html', {'post_id': post_id})
